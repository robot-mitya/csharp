MJPEG Decoder v1.1
by Brian Peek (http://www.brianpeek.com/)

There are 4 assemblies in this package.  Select the one that matches the project type you're building:

MjpegProcessorSL.dll � Silverlight (Out of Browser Only!) 
MjpegProcessorWP7.dll � Windows Phone 7 (XNA or Silverlight) 
MjpegProcessorXna4.dll � XNA 4.0 (Windows) 
MjpegProcessor.dll � WinForms and WPF 

See the full article at Coding4Fun:
http://channel9.msdn.com/coding4fun/articles/MJPEG-Decoder


Changelog
---------
v1.1
	- Credentials can be passed to ParseStream (thanks to patricker for the suggestion)
